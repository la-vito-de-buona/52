let min_top = 120;
let max_top = 720;
let min_left = 810;
let max_left = 1610;
const elem = document.getElementById("square");
let colors = ["purple", "green", "red", "blue", "black", "white", "brown", "yellow"];

document.getElementById("square").addEventListener("click", () => {
    elem.style.top = Math.random() * (max_top - min_top) + min_top + "px";
    elem.style.left = Math.random() * (max_left - min_left) + min_left + "px";
    elem.style.backgroundColor = colors[Math.floor(Math.random() * colors.length)];
});