let k1 = 0; let k2 = 0; let k3 = 0; let k4 = 0; let k5 = 0; let k6 = 0;

document.getElementById('icon1').addEventListener("click", () => {
    if (k1 == 0){
         document.getElementById('lower1').innerHTML = "(добавлен в корзину)";
         document.getElementById('icon1').style.backgroundColor = "#444343";
         k1++;
    }
    else{
        document.getElementById('icon1').style.backgroundColor = "#BC2E2E";
        document.getElementById('lower1').innerHTML = "";
        k1--;
    }
});

document.getElementById('icon2').addEventListener("click", () => {
    if (k2 == 0){
         document.getElementById('lower2').innerHTML = "(добавлен в корзину)";
         document.getElementById('icon2').style.backgroundColor = "#444343";
         k2++;
    }
    else{
        document.getElementById('icon2').style.backgroundColor = "#BC2E2E";
        document.getElementById('lower2').innerHTML = "";
        k2--;
    }
});

document.getElementById('icon3').addEventListener("click", () => {
    if (k3 == 0){
         document.getElementById('lower3').innerHTML = "(добавлен в корзину)";
         document.getElementById('icon3').style.backgroundColor = "#444343";
         k3++;
    }
    else{
        document.getElementById('icon3').style.backgroundColor = "#BC2E2E";
        document.getElementById('lower3').innerHTML = "";
        k3--;
    }
});

document.getElementById('icon4').addEventListener("click", () => {
    if (k4 == 0){
         document.getElementById('lower4').innerHTML = "(добавлен в корзину)";
         document.getElementById('icon4').style.backgroundColor = "#444343";
         k4++;
    }
    else{
        document.getElementById('icon4').style.backgroundColor = "#BC2E2E";
        document.getElementById('lower4').innerHTML = "";
        k4--;
    }
});

document.getElementById('icon5').addEventListener("click", () => {
    if (k5 == 0){
         document.getElementById('lower5').innerHTML = "(добавлен в корзину)";
         document.getElementById('icon5').style.backgroundColor = "#444343";
         k5++;
    }
    else{
        document.getElementById('icon5').style.backgroundColor = "#BC2E2E";
        document.getElementById('lower5').innerHTML = "";
        k5--;
    }
});

document.getElementById('icon6').addEventListener("click", () => {
    if (k6 == 0){
         document.getElementById('lower6').innerHTML = "(добавлен в корзину)";
         document.getElementById('icon6').style.backgroundColor = "#444343";
         k6++;
    }
    else{
        document.getElementById('icon6').style.backgroundColor = "#BC2E2E";
        document.getElementById('lower6').innerHTML = "";
        k6--;
    }
});